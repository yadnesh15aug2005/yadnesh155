package ExceptionHandlingDemo;
import java.lang.Exception;

public class DivisionException extends Exception{
   public DivisionException(String msg){
        super(msg);
    }

}
