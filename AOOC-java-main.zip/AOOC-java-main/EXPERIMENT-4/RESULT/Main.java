public class Main{
    public static void main(String[] args){
        Result re = new Result();
        re.set_marks(77, 87);
        re.set(25);
        re.display();
    }
}
