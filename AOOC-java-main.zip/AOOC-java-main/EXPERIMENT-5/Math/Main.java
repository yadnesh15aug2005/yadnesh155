import MathOperations.Mathop;

public class Main{
    public static void main(String[] args){
        Mathop math = new Mathop();

        System.out.println("-----operations on 2.6--------");
        math.operations(2.6);

        System.out.println("----operations on -7.5--------");
        math.operations(-7.5);
    }
}
