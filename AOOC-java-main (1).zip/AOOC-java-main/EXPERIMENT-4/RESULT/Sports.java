interface Sports{
    int sMarks = 23;
    int get_marks();
    void set(int sm);
}
