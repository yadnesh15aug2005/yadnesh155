public class Student{
    private int roll_no;

    public int get_roll_no(){
        return(roll_no);
    }

    public void set_roll_no(int r){
        this.roll_no = r;
    }
}
