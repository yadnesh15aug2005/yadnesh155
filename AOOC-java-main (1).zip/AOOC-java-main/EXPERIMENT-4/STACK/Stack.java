interface Stack{
    int size = 50;
    void push();
    int pop();
    void display();
    boolean overflow();
    boolean underflow();
}
